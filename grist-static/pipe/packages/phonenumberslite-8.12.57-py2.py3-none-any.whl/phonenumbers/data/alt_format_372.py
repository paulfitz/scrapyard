"""Auto-generated file, do not edit by hand. 372 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_372 = [NumberFormat(pattern='(\\d)(\\d{3})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['6']), NumberFormat(pattern='(\\d{2})(\\d{2})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['[4-79]']), NumberFormat(pattern='(\\d{2})(\\d{3})(\\d{2})', format='\\1 \\2 \\3', leading_digits_pattern=['[4-79]'])]
